﻿namespace RogueLikeMapBuilder
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pgMapBuilderProperties = new System.Windows.Forms.PropertyGrid();
            this.pnMapView = new System.Windows.Forms.Panel();
            this.cbBuildMethods = new System.Windows.Forms.ComboBox();
            this.lblBuildSelected = new System.Windows.Forms.LinkLabel();
            this.SuspendLayout();
            // 
            // pgMapBuilderProperties
            // 
            this.pgMapBuilderProperties.Location = new System.Drawing.Point(13, 24);
            this.pgMapBuilderProperties.Name = "pgMapBuilderProperties";
            this.pgMapBuilderProperties.Size = new System.Drawing.Size(232, 437);
            this.pgMapBuilderProperties.TabIndex = 0;
            this.pgMapBuilderProperties.ToolbarVisible = false;
            // 
            // pnMapView
            // 
            this.pnMapView.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnMapView.Location = new System.Drawing.Point(251, 24);
            this.pnMapView.Name = "pnMapView";
            this.pnMapView.Size = new System.Drawing.Size(200, 100);
            this.pnMapView.TabIndex = 1;
            this.pnMapView.Paint += new System.Windows.Forms.PaintEventHandler(this.pnMapView_Paint);
            // 
            // cbBuildMethods
            // 
            this.cbBuildMethods.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbBuildMethods.FormattingEnabled = true;
            this.cbBuildMethods.Location = new System.Drawing.Point(13, 1);
            this.cbBuildMethods.Name = "cbBuildMethods";
            this.cbBuildMethods.Size = new System.Drawing.Size(196, 21);
            this.cbBuildMethods.TabIndex = 4;
            // 
            // lblBuildSelected
            // 
            this.lblBuildSelected.AutoSize = true;
            this.lblBuildSelected.Location = new System.Drawing.Point(215, 4);
            this.lblBuildSelected.Name = "lblBuildSelected";
            this.lblBuildSelected.Size = new System.Drawing.Size(30, 13);
            this.lblBuildSelected.TabIndex = 5;
            this.lblBuildSelected.TabStop = true;
            this.lblBuildSelected.Text = "Build";
            this.lblBuildSelected.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lblBuildSelected_LinkClicked);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(620, 548);
            this.Controls.Add(this.lblBuildSelected);
            this.Controls.Add(this.cbBuildMethods);
            this.Controls.Add(this.pnMapView);
            this.Controls.Add(this.pgMapBuilderProperties);
            this.Name = "Form1";
            this.Text = "RogueLikeMapBuilder";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PropertyGrid pgMapBuilderProperties;
        private System.Windows.Forms.Panel pnMapView;
        private System.Windows.Forms.ComboBox cbBuildMethods;
        private System.Windows.Forms.LinkLabel lblBuildSelected;
    }
}

