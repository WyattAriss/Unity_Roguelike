﻿using System;
using System.Drawing;
using System.Windows.Forms;
using System.Reflection;

namespace RogueLikeMapBuilder
{
    public partial class Form1 : Form
    {

        Size blocksize = new Size(3, 3);//defines the size of a pixel on the map

        csMapbuilder mpbuild;

        public Form1()
        {
            InitializeComponent();           
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            mpbuild = new csMapbuilder(150, 150);
            pgMapBuilderProperties.SelectedObject = mpbuild;
            ConfigureSize();

            //each public method in the class csMapBuilder with starts with build_
            //is added to the combobox cbBuildMethods
            foreach (MethodInfo meth in mpbuild.GetType().GetMethods())
                if (meth.Name.StartsWith("Build_"))
                    cbBuildMethods.Items.Add(meth.Name);

            cbBuildMethods.SelectedIndex = 0;
            lblBuildSelected_LinkClicked(null, null);

        }
       
        //change the size of the panel and the form based on the map size
        private void ConfigureSize()
        {
            pnMapView.Width = mpbuild.Map_Size.Width * blocksize.Width;
            pnMapView.Height = mpbuild.Map_Size.Height * blocksize.Height;
            this.Width = pnMapView.Width + pnMapView.Left + 50;
            this.Height = pnMapView.Height + pnMapView.Top + 50;
        }

        //draw the map
        private void pnMapView_Paint(object sender, PaintEventArgs e)
        {
            using (SolidBrush sbBlack = new SolidBrush(Color.Black))
            {
                for (int x = 0; x < mpbuild.map.GetLength(0); x++)
                    for (int y = 0; y < mpbuild.map.GetLength(1); y++)
                        if (mpbuild.map[x, y] == 0)
                            e.Graphics.FillRectangle(sbBlack, new Rectangle(x * blocksize.Width, y * blocksize.Height, blocksize.Width, blocksize.Height));
            }
        }


        //call the build method selected in cbBuildMethods
        private void lblBuildSelected_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            if (cbBuildMethods.Text != "")
            {
                ConfigureSize();

                

                MethodInfo buildmethod = mpbuild.GetType().GetMethod(cbBuildMethods.Text);
                object result = buildmethod.Invoke(mpbuild, null);

                if ((bool)result == true)
                {
                    pnMapView.Invalidate();
                    pgMapBuilderProperties.Refresh();
                }
                else
                    MessageBox.Show("Break out counter exceeded!");

            }
        }
    }
}
