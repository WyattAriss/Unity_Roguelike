The files contained here are the files which I originally built the plasmaball image from.
They are screenshots from a Wikimedia Commons video file licensed under CC-BY-SA. The original author is Geni.
http://commons.wikimedia.org/wiki/File:Plasmaball_vid2.ogg

Please attribute this work to both Geni and me (Thane Brimhall).
